

"""
Process prompts
"""

def promptResponse(prompt) -> str:
    response = f" This prompt has been modified: {prompt}"
    
    return response


